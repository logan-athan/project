import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet ("/update_medical_history")
public class Update_medical_history extends HttpServlet  {
     protected void doGet(HttpServletRequest request, HttpServletResponse response) 
     {

          try
          {
          PrintWriter out=response.getWriter();
          response.setContentType("text/html");
          Class.forName("com.mysql.jdbc.Driver");
          Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/mysql","root","root");
          int report_id=Integer.parseInt(request.getParameter("tf1"));
          String customer_id = request.getParameter("tf2");
          String doctor_id = request.getParameter("tf3");
          int medicare_service_id =Integer.parseInt(request.getParameter("tf4"));
          int actual_value =Integer.parseInt(request.getParameter("tf5"));
          int normal_range =Integer.parseInt(request.getParameter("tf6"));
          
          
          
          PreparedStatement stmt=con.prepareStatement("update medical_test_history set report_id=?,doctor_id=?, medicare_service_id=?, diag1_actual_value=?, diag1_normal_range=? where customer_id=?");
        stmt.setInt(1, report_id); 
        stmt.setString(2, doctor_id);
        stmt.setInt(3, medicare_service_id); 
        stmt.setInt(4, actual_value); 
        stmt.setInt(5, normal_range);
        stmt.setString(6, customer_id);
          
          
          stmt.executeUpdate();
          
          request.setAttribute("Message", "Updated Successfully");
          RequestDispatcher reqDis=getServletConfig().getServletContext().getRequestDispatcher("/displayMessage.jsp");
         reqDis.forward(request,response);
          }
          catch (Exception ex)
          {
              System.out.println("Exception is "+ex);
          }
     }
}

