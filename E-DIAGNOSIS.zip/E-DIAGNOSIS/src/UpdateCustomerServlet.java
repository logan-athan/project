import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/UpdateCustomerServlet")
public class UpdateCustomerServlet extends HttpServlet 
{
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		try
		{
			Connection con=null;
			ResultSet rs=null;
			PreparedStatement ps=null;

		//HttpSession hs1=request.getSession();
		//String user=(String)hs1.getAttribute("user_id");
		//String customer_id=(String)hs1.getAttribute("cus_id");
		PrintWriter out=response.getWriter();
		response.setContentType("text/html");
		  Class.forName("com.mysql.jdbc.Driver");
		 con=DriverManager.getConnection("jdbc:mysql://localhost:3306/mysql", "root","root");

		  
		  String customerid = request.getParameter("data");
		  
		  
		  String dataArr[] = customerid.split(":");
		  
		              ps=con.prepareStatement("update Status set status='approved' where id=? ");
		  for (int i = 0; i < dataArr.length; ++i)
		  {
		         System.out.println (dataArr[i]);
		              ps.setString(1, (dataArr[i]));
		              ps.executeUpdate();
		              
		              
		  }
		  //out.println("Your Details are Updated Successfully!!");
		              
 
		  
		  
		  
		
		
		out.println("<div align=right><a href=SignOutServlet>SignOut</a></div><br>");
		//out.println("<center><b><h1>Customer Request is Accepted.</h1></b></center>");
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
}