import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
@WebServlet("/RegistercustomerServlet")
public class RegistercustomerServlet extends HttpServlet 
{
                
  protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
     {

        try
        {
               HttpSession hs1=request.getSession();
                                hs1.setAttribute("user_id",request.getParameter("tf1"));
                                PrintWriter out=response.getWriter();
                                response.setContentType("text/html");
                                Class.forName("com.mysql.jdbc.Driver");
                                Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/mysql","root","root");
                                String cusid=request.getParameter("tf1");
                                String firstname=request.getParameter("tf2");
                                String lastname=request.getParameter("tf3");
                                int age=Integer.parseInt(request.getParameter("tf4"));
                                String gender=request.getParameter("tf");
                                String dob=request.getParameter("tf5");
                                long no=Long.parseLong(request.getParameter("tf6"));
                                long no1=Long.parseLong(request.getParameter("tf7"));
                                String emailid=request.getParameter("tf8");
                                String pwd=request.getParameter("tf9");
                                String add1=request.getParameter("tf10"); 
                                String add2=request.getParameter("tf11");
                                String city=request.getParameter("tf12");
                                String state=request.getParameter("tf13");
                                String zip=request.getParameter("tf14");
                                RequestDispatcher rd=null;
                                PreparedStatement stmt=con.prepareStatement("insert into customer values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
                                stmt.setString(1,cusid);
                                stmt.setString(2,firstname);
                                stmt.setString(3,lastname);
                                stmt.setInt(4,age); 
                                stmt.setString(5, gender);
                                stmt.setString(6, dob);
                                stmt.setLong(7, no);
                                stmt.setLong(8, no1);
                                stmt.setString(9, emailid);
                                stmt.setString(10, pwd);
                                stmt.setString(11, add1);
                                stmt.setString(12, add2);
                                stmt.setString(13, city);
                                stmt.setString(14, state);
                                stmt.setString(15, zip);
                                stmt.executeUpdate();
                                PreparedStatement stmt1=con.prepareStatement("insert into status values(?,?,?)");
                                stmt1.setString(1,cusid);
                                stmt1.setString(2,"customer");
                                stmt1.setString(3,"Not-approved");
                                stmt1.executeUpdate();

                                response.sendRedirect("http://localhost:8080/E-DIAGNOSIS/nextpagecustomer.jsp");
           // out.println("<body ><b><center><h1>Your details are submitted successfully.</h1><center></b></body>");
           //out.println("<div align=right>Welcome "+cusid+"</div>");
                                //out.println("<div align=right><a href=http://localhost:8080/MainProject/SignOutServlet>SignOut</a></div><br>");
       }
        catch(Exception e)
        {
          e.printStackTrace();
        }
     }
  }
