package test;

public class Medical_Test_History {
     
     int report_id;
     String doctor_id;
     int medicare_service_id;
     int actual_value;
     int normal_range;
     String Customer_id;
     public int getReport_id() {
          return report_id;
     }
     public void setReport_id(int report_id) {
          this.report_id = report_id;
     }
     public String getDoctor_id() {
          return doctor_id;
     }
     public void setDoctor_id(String doctor_id) {
          this.doctor_id = doctor_id;
     }
     public int getMedicare_service_id() {
          return medicare_service_id;
     }
     public void setMedicare_service_id(int medicare_service_id) {
          this.medicare_service_id = medicare_service_id;
     }
     public int getActual_value() {
          return actual_value;
     }
     public void setActual_value(int actual_value) {
          this.actual_value = actual_value;
     }
     public int getNormal_range() {
          return normal_range;
     }
     public void setNormal_range(int normal_range) {
          this.normal_range = normal_range;
     }
     public String getCustomer_id() {
          return Customer_id;
     }
     public void setCustomer_id(String customer_id) {
          Customer_id = customer_id;
     }
     
     
     

}

