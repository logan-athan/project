
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
@WebServlet("/AgentDetailsServlet")
public class AgentDetailsServlet extends HttpServlet 
{
       protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
       {
              try
              {
              HttpSession hs1=request.getSession();
              String user=(String)hs1.getAttribute("user_id");
              //String doctor_id=(String)hs1.getAttribute("cus_id");
              PrintWriter out=response.getWriter();
              response.setContentType("text/html");
              Class.forName("com.mysql.jdbc.Driver");
              Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/mysql","root","root");
              PreparedStatement stmt=con.prepareStatement("select agent_id,first_name,age,gender,contact_number,email_id,city,state from agent");
              ResultSet rs=stmt.executeQuery();
              request.setAttribute("result",rs);
              RequestDispatcher reqDis=getServletConfig().getServletContext().getRequestDispatcher("/DisplayAgentDetails.jsp");
              reqDis.forward(request,response);
              }
              catch(Exception e)
              {
                     e.printStackTrace();
              }
       }
}
