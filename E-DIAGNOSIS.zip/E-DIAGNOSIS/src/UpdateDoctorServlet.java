import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/UpdateDoctorServlet")
public class UpdateDoctorServlet extends HttpServlet 
{
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		try
		{
			Connection con=null;
			ResultSet rs=null;
			PreparedStatement ps=null;

		//HttpSession hs1=request.getSession();
		//String user=(String)hs1.getAttribute("user_id");
		//String customer_id=(String)hs1.getAttribute("cus_id");
		PrintWriter out=response.getWriter();
		response.setContentType("text/html");
		  Class.forName("com.mysql.jdbc.Driver");
		 con=DriverManager.getConnection("jdbc:mysql://localhost:3306/mysql", "root","root");

		  
		  String doctorid = request.getParameter("data1");
		  
		  
		  String dataArr1[] = doctorid.split(":");
		  
		              ps=con.prepareStatement("update Status set status='approved' where id=? ");
		  for (int i = 0; i < dataArr1.length; ++i)
		  {
		         System.out.println (dataArr1[i]);
		              ps.setString(1, (dataArr1[i]));
		              ps.executeUpdate();
		              
		              
		  }
		  //out.println("Your Details are Updated Successfully!!");
		              response.sendRedirect("np.jsp");
 
		  
		  
		  
		
		
		out.println("<div align=right><a href=SignOutServlet>SignOut</a></div><br>");
		//out.println("<center><b><h1>Customer Request is Accepted.</h1></b></center>");
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
}