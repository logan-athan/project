

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try
		{
		int c=0;
		  HttpSession hs1=request.getSession();
          hs1.setAttribute("user_id",request.getParameter("id"));
		
		PrintWriter out=response.getWriter();
		response.setContentType("text/html");
		
		Class.forName("com.mysql.jdbc.Driver");
		Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/mysql","root","root");

		String id=request.getParameter("id");
		String password=request.getParameter("password");
		PreparedStatement stmt=con.prepareStatement("select admin_id,password  from admin where admin_id=? and password=?");
		//System.out.println(stmt.toString());
		stmt.setString(1, id);
		stmt.setString(2, password);
		System.out.println(stmt.toString());
		
		ResultSet rs=stmt.executeQuery();
		RequestDispatcher rd=null;
		
		while(rs.next())
		{
	
				c++;
				

		}
		if(c==1)
		{
		     response.sendRedirect("adminloginpage.jsp");
			
			
		}
			else
			{ 
				//rd=request.getRequestDispatcher("/Login.jsp");
				
				//rd.include(request,response);
				//out.println("<b><center><h2><marquee direction=right > Invalid Credentials</marquee></h2></center></b>");
				
				String message = "Invalid Credentials";
				request.setAttribute("message", message);

		 		//Servlet JSP communication
				RequestDispatcher reqDispatcher = getServletConfig().getServletContext().getRequestDispatcher("/InvalidUser.jsp");
				reqDispatcher.forward(request,response);

				
				//System.out.println(rs.getString(1));
				//System.out.println(rs.getString(2));
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
}
	